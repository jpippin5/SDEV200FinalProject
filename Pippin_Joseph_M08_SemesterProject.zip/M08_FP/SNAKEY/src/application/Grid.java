package application;

public class Grid {
	 // Fields
    private int gameSpeed;
    private int gridSize;
    private int score;
    private boolean gameStart;
    private boolean gameOver;
    private String instructions;


    // Constructor
    public Grid(String speed, String size) {
        // Initialize score, size, and gameSpeed
        this.score = 0;
        this.gameStart = true;
        this.gameOver = false;
        this.instructions = "Use arrow keys to direct SNAKEY";
        
        switch (speed) {
            case "Slow": this.gameSpeed = 800;
                    break;
            case "Medium": this.gameSpeed = 500;
                    break;
            case "Fast": this.gameSpeed = 200;
                    break;
            default: this.gameSpeed = 800;
        }
        
        switch (size) {
        	case "Small": this.gridSize = 10;
        			break;
        	case "Medium": this.gridSize = 15;
        			break;
        	case "Large": this.gridSize = 20;
        			break;
        	default: this.gridSize = 10;
        }
    }


    // Get and Set Methods
    public int getGameSpeed() {
        return this.gameSpeed;
    }

    public void setGameSpeed(int gs) {
        this.gameSpeed = gs;
    }

    public int getSize() {
        return this.gridSize;
    }

    public void setSize(int s) {
        this.gridSize = s;
    }

    public int getScore() {
        return this.score;
    }

    public void setScore(int s) {
        this.score = s;
    }
    
    public boolean getGameStart() {
    	return this.gameStart;
    }
    
    public void setGameStart(boolean gs) {
    	this.gameStart = gs;
    }
    
    public boolean getGameOver() {
        return this.gameOver;
    }

    public void setGameOver(boolean go) {
        this.gameOver = go;
    }
    
    public String getInstructions() {
    	return this.instructions;
    }
    
    public void setInstructions(String ins) {
    	this.instructions = ins;
    }

    // Other Methods
    public void addScore() {
        this.score += 1;
    }
}
