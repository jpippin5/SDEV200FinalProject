
package application;
	
import java.util.Timer;
import java.util.TimerTask;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;


public class Main extends Application {
	
	// Normal Java program entrance
	public static void main(String[] args) {
		// launch sends to Main.start() method
		launch(args);		
	}
	
	@Override
	public void start(Stage stage) {
		
		// Used to completely close the app when the window X is clicked, this way my timer does not keep running in the background
		stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
		    @Override
		    public void handle(WindowEvent event) {
		        Platform.exit();
		        System.exit(0);
		    }
		});
		
		// Whenever start is called, create new blank menuPane and gamePane
		GridPane menuPane = new GridPane();
		GridPane gamePane = new GridPane();
		
		// Format gamePane
		gamePane.setAlignment(Pos.TOP_CENTER);
		gamePane.setVgap(1);
		gamePane.setHgap(1);
		
		// Populate and format menu pane
			// Format
			menuPane.setAlignment(Pos.CENTER);
			menuPane.setHgap(5);
			menuPane.setVgap(5);
			
			// Make, format, and place title label
			Label lblTitle = new Label("SNAKEY");
			lblTitle.setFont(Font.font(30));
			GridPane.setColumnSpan(lblTitle, 2);
			GridPane.setRowSpan(lblTitle, 5);
			GridPane.setHalignment(lblTitle, HPos.CENTER);
			GridPane.setValignment(lblTitle, VPos.CENTER);
			menuPane.add(lblTitle, 0, 0);
			
			// Make and place selection labels and radios
				// Speed label
				menuPane.add(new Label("Speed:"), 0, 6);
				
				// Speed radios
				ToggleGroup tgSpeed = new ToggleGroup();
				RadioButton radSlow = new RadioButton("Slow");
				RadioButton radMediumSp = new RadioButton("Medium");
				RadioButton radFast = new RadioButton("Fast");
				radSlow.setSelected(true);
				radSlow.setToggleGroup(tgSpeed);
				radSlow.setFocusTraversable(false);
				radMediumSp.setToggleGroup(tgSpeed);
				radFast.setToggleGroup(tgSpeed);
				menuPane.add(radSlow, 1, 6);
				menuPane.add(radMediumSp, 1, 7);
				menuPane.add(radFast, 1, 8);
				
				// Size label
				menuPane.add(new Label("Grid Size:"), 0, 10);
			
				// Size radios
				ToggleGroup tgSize = new ToggleGroup();
				RadioButton radSmall = new RadioButton("Small");
				RadioButton radMediumSi = new RadioButton("Medium");
				RadioButton radLarge = new RadioButton("Large");
				radSmall.setSelected(true);
				radSmall.setToggleGroup(tgSize);
				radSmall.setFocusTraversable(false);
				radMediumSi.setToggleGroup(tgSize);
				radLarge.setToggleGroup(tgSize);
				menuPane.add(radSmall, 1, 10);
				menuPane.add(radMediumSi, 1, 11);
				menuPane.add(radLarge, 1, 12);		
			
			// Make and place new game button
			Button btnNewGame = new Button("Start New Game");
			GridPane.setColumnSpan(btnNewGame, 2);
			menuPane.add(btnNewGame, 0, 14);
			
		// End menu pane formating and population		
			
		// Create menu scene and put it on stage
		Scene menuScene = new Scene(menuPane, 225, 250);		
		stage.setResizable(false);
		stage.setTitle("SNAKEY");
		stage.setScene(menuScene);
		stage.show();
		
		// Give new game button its function to call createGameObjects
		btnNewGame.setOnAction(e -> {
			createGameObjects(stage, gamePane, tgSpeed, tgSize);
		});		
	}
	
	public void createGameObjects(Stage stage, GridPane gamePane, ToggleGroup tgSpeed, ToggleGroup tgSize) {
		
		// Get radios selected on menu
		RadioButton selectedSpeed = (RadioButton) tgSpeed.getSelectedToggle();
		RadioButton selectedSize = (RadioButton) tgSize.getSelectedToggle();
		String strSpeed = selectedSpeed.getText();
		String strSize = selectedSize.getText();
			
		// Create grid, snake, and apple objects
		Grid gr = new Grid(strSpeed, strSize);
		Snake sn = new Snake(gr.getSize());
		Apple ap = new Apple(gr.getSize(), sn);
		
		// Create the gameScene and place it on stage, gamePane will be populated on update		
		Scene gameScene = new Scene(gamePane, (gr.getSize() + 1) * 21, (gr.getSize() + 2.5) * 21);
		stage.setScene(gameScene);
		
		// Create timer to call game loop at set interval, create here so start over button will cancel it when clicked
		Timer timer = new Timer();
		
		// Create button to start new game on game pane
		Button btnStartOver = new Button("New Game");
		GridPane.setColumnSpan(btnStartOver, 4);
		GridPane.setHalignment(btnStartOver, HPos.RIGHT);
		btnStartOver.setFocusTraversable(false);		
		
		// Give start over button its functionality
		btnStartOver.setOnAction(e -> {
			timer.cancel();
			start(stage);
		});
				
		// On key press, set input direction (if directional key)
		gameScene.setOnKeyPressed(e -> {
			sn.setInputDirection(e.getCode());
		});	
		
		// Objects made, call updateGamePane initially
		updateGamePane(stage, gameScene, gamePane, gr, sn, ap, timer, btnStartOver);
		
		// Enter gameLoop
		gameLoop(stage, gameScene, gamePane, gr, sn, ap, timer, btnStartOver);
	}
	
	public void updateGamePane(Stage stage, Scene gameScene, GridPane gamePane, Grid gr, Snake sn, Apple ap, Timer timer, Button btnStartOver) {
		
		// Whenever updateGamePane is called, clear the pane
		gamePane.getChildren().clear();

		// Make, format, and place gamePane labels.  Place new game button
		Label lblScore = new Label("SCORE:");
		GridPane.setColumnSpan(lblScore, 3);
		gamePane.add(lblScore, 0, gr.getSize() + 2);
		
		Label lblScoreAmount = new Label(String.valueOf(gr.getScore()));
		GridPane.setColumnSpan(lblScoreAmount, gr.getSize());
		gamePane.add(lblScoreAmount, 3, gr.getSize() + 2);
		
		Label lblDirections = new Label(gr.getInstructions());
		GridPane.setColumnSpan(lblDirections, gr.getSize());
		gamePane.add(lblDirections, 0, gr.getSize() + 3);
		
		gamePane.add(btnStartOver, gr.getSize() - 4, gr.getSize() + 2);
		
		// Fill in positions with empty, apple, or snake squares
		for (int x = 0; x < gr.getSize(); x++) {
			for (int y = 0; y < gr.getSize(); y++) {
				if (x == ap.getCurrentPosition()[0][0] && y == ap.getCurrentPosition()[0][1]) {
					gamePane.add(new Rectangle(20, 20, Color.RED), x, y);
				
				} else {
					gamePane.add(new Rectangle(20, 20, Color.TAN), x, y);
				}
				for (int s = 0; s < sn.getLength(); s++) {
					if (x == sn.getCurrentPosition()[s][0] && y == sn.getCurrentPosition()[s][1]) {
						gamePane.add(new Rectangle(20, 20, Color.GREEN), x, y);
					} 
				}				
			}
		}		
	}

	public void gameLoop(Stage stage, Scene gameScene, GridPane gamePane, Grid gr, Snake sn, Apple ap, Timer timer, Button btnStartOver) {
		
	    // If gameStart is true, game is ready to start but not started yet, change when inputDirection changes from init Q
	    if (gr.getGameStart() == true) {
	        if (sn.getInputDirection() != KeyCode.Q) {
	            gr.setGameStart(false); // Game started
	        }
	    }
	    
	    // If gameStart is false, game is playing, check if gameOver 
	    if (gr.getGameStart() == false) {
	    	// MAIN GAME LOOP 1. Update input 2. Update snakey position 3. Check collisions 4. New apple 5. Update game pane 6. Call gameloop again

	            // 1. Update input
	            if ((sn.getLength() > 1) && ((sn.getCurrentDirection() == KeyCode.UP && sn.getInputDirection() == KeyCode.DOWN) || (sn.getCurrentDirection() == KeyCode.DOWN && sn.getInputDirection() == KeyCode.UP) || (sn.getCurrentDirection() == KeyCode.LEFT && sn.getInputDirection() == KeyCode.RIGHT) || (sn.getCurrentDirection() == KeyCode.RIGHT && sn.getInputDirection() == KeyCode.LEFT))) {
	                // If input direction turns back, invalid input, do not change direction
	            } 
	            // If input direction does not turn back, update current direction
	            else {
	                sn.setCurrentDirection(sn.getInputDirection());
	            }
	            
	            // 2. Update snakey position
	            // Store previous snakey position
	            for (int i = 0; i < sn.getLength(); i++) {
	                for (int j = 0; j < 2; j++) {
	                    sn.setPreviousPosition(i, sn.getCurrentPosition());
	                }
	            }
	            // Update snakey head
	            switch (sn.getCurrentDirection()) {
	                case UP: sn.setCurrentPosition(0, sn.getPreviousPosition()[0][0], sn.getPreviousPosition()[0][1] - 1); 
	                    break;
	                case DOWN: sn.setCurrentPosition(0, sn.getPreviousPosition()[0][0], sn.getPreviousPosition()[0][1] + 1);
	                    break;
	                case LEFT: sn.setCurrentPosition(0, sn.getPreviousPosition()[0][0] - 1, sn.getPreviousPosition()[0][1]);
	                    break;
	                case RIGHT: sn.setCurrentPosition(0, sn.getPreviousPosition()[0][0] + 1, sn.getPreviousPosition()[0][1]);
	                    break;
	                default: ;
	            }
	            // Update rest of snakey
	            for (int i = 1; i < sn.getLength(); i++) {
	                sn.setCurrentPosition(i, sn.getPreviousPosition()[i - 1][0], sn.getPreviousPosition()[i - 1][1]);
	            }
	            
	            // 3. Check for collisions
	            // Check for collision with apple, only have to check snakey head for collision
	            if ((sn.getCurrentPosition()[0][0] == ap.getCurrentPosition()[0][0]) && (sn.getCurrentPosition()[0][1] == ap.getCurrentPosition()[0][1])) {
	                ap.setEaten(true);
	            }
	            // Check for collision with wall, only have to check snakey head for collision
	            if ((sn.getCurrentPosition()[0][0]) < 0 || sn.getCurrentPosition()[0][0] > (gr.getSize() - 1) || sn.getCurrentPosition()[0][1] < 0 || sn.getCurrentPosition()[0][1] > (gr.getSize() - 1)) {
	                gr.setGameOver(true);
	                gr.setInstructions("Game Over. You went off the edge.");
	            }
	            // Check for collision with tail, only have to check snakey head for collision with tail of length 4 or longer
	            if (sn.getLength() > 4) {
	                for (int i = 4; i < sn.getLength(); i++) {
	                    if ((sn.getCurrentPosition()[0][0] == sn.getCurrentPosition()[i][0]) && (sn.getCurrentPosition()[0][1] == sn.getCurrentPosition()[i][1])) {
	                        gr.setGameOver(true);
	                        gr.setInstructions("Game Over. You bit your tail.");
	                    }
	                }
	            }
	            
	            // 4. New apple if needed, grow snake
	            if (ap.getEaten() == true) {
	                // Temp store last position of previous add onto snake
	                int x = sn.getPreviousPosition()[sn.getLength() - 1][0];
	                int y = sn.getPreviousPosition()[sn.getLength() - 1][1];
	                // Increase length and score
	                sn.addLength();
	                gr.addScore();
	                // Make a new previous array one unit bigger
	                sn.longerPreviousPosition();
	                // Store current position in previous array
	                for (int i = 0; i < (sn.getLength() - 1); i++) {
	                    sn.setPreviousPosition(i, sn.getCurrentPosition()[i][0], sn.getCurrentPosition()[i][1]);
	                }
	                sn.longerCurrentPosition();
	                for (int i = 0; i < sn.getLength() - 1; i ++) {
	                    sn.setCurrentPosition(i, sn.getPreviousPosition()[i][0], sn.getPreviousPosition()[i][1]);
	                }
	                sn.setCurrentPosition(sn.getLength() - 1, x, y);
	                ap.setCurrentPosition(0, ap.getNewPos(gr.getSize(), sn));
	                ap.setEaten(false);
	            }
	            
	            // 5. Update gamePane
	            updateGamePane(stage, gameScene, gamePane, gr, sn, ap, timer, btnStartOver);
	        }   

	    // 6. Call gameloop again if gameOver false
	    if (gr.getGameOver() == false) {
	        // Create task to run when timer reaches 0, which is to call the gameloop again
	        TimerTask task = new TimerTask() {
	            @Override
	            public void run() {
	                Platform.runLater(() -> 
	                {
	                    gameLoop(stage, gameScene, gamePane, gr, sn, ap, timer, btnStartOver);				
	                });
	            }
	        };
	        timer.schedule(task, gr.getGameSpeed());
	    }
	}
}