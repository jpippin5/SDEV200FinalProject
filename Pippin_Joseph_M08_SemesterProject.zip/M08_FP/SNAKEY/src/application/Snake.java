package application;

import javafx.scene.input.KeyCode;

public class Snake extends MovableParts {
	// Fields
    private boolean alive;
    private KeyCode inputDirection;
    private KeyCode currentDirection;
    private int[][] previousPosition;


    // Constructor
    public Snake(int si) {
        this.alive = true;
        this.inputDirection = KeyCode.Q;
        this.setLength(1);
        this.currentDirection = KeyCode.Q;
        this.setCurrentPosition(0, getNewPos(si));
        this.previousPosition = new int[1][2];
    }

    // Method
    public boolean getAlive() {
        return this.alive;
    }

    public void setAlive(boolean a) {
        this.alive = a;
    }
    
    public KeyCode getInputDirection() {
    	return this.inputDirection;
    }
    
    public void setInputDirection(KeyCode last) {
    	if (last == KeyCode.UP || last == KeyCode.DOWN || last == KeyCode.LEFT || last == KeyCode.RIGHT) {
    		this.inputDirection = last;
    	}
    }

    public KeyCode getCurrentDirection() {
        return this.currentDirection;
    }

    public void setCurrentDirection(KeyCode d) {
        this.currentDirection = d;
    }

    public int[][] getPreviousPosition() {
        return this.previousPosition;
    }

    public void setPreviousPosition(int i, int x, int y) {
        this.previousPosition[i][0] = x;
        this.previousPosition[i][1] = y;
    }

    public void setPreviousPosition(int i, int[][] a) {
        this.previousPosition[i][0] = a[i][0];
        this.previousPosition[i][1] = a[i][1];
    }
    
    public void longerPreviousPosition() {
    	this.previousPosition = new int [this.getLength()][2];
    }
    // Other Methods


    // Overrides
    @Override
    public int[][] getNewPos() {
        int[][] newPos = getNewPos();
        return newPos;
    }

    public int[][] getNewPos(int size) {
        int x = (int)(Math.random() * (size - 1));
        int y = (int)(Math.random() * (size - 1));
        int[][] newPos = new int[1][2];
        newPos[0][0] = x;
        newPos[0][1] = y;
        return newPos;
    }

}
