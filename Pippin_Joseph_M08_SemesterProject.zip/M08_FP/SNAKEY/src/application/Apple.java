package application;

public class Apple extends MovableParts {

	// Fields
    private boolean eaten;

    // Constructor
    public Apple(int si, Snake sn) {
        this.eaten = false;
        this.setLength(1);
        this.setCurrentPosition(0, getNewPos(si, sn));
    }


    // Method
    public boolean getEaten() {
        return this.eaten;
    }

    public void setEaten(boolean a) {
        this.eaten = a;
    }


    // Overrides
    @Override
    public int[][] getNewPos() {
        int[][] newPos = getNewPos();
        return newPos;
    }

    public int[][] getNewPos(int si, Snake sn) {
        boolean spotTaken = false;
        int[][] newPos = new int[1][2];
        int x;
        int y;

        do {
            x = (int)(Math.random() * (si - 1));
            y = (int)(Math.random() * (si - 1));

            for (int i = 0; i < sn.getLength(); i++) {
                if (x == sn.getCurrentPosition()[i][0] && y == sn.getCurrentPosition()[i][1]) {
                    spotTaken = true;                    
                }                
            }
        } while (spotTaken == true);

        newPos[0][0] = x;
        newPos[0][1] = y;
        
        this.setCurrentPosition(0, x, y);

        return newPos;
        
    }

}
