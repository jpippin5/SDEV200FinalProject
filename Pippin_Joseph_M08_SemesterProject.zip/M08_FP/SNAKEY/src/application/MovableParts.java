package application;

public abstract class MovableParts {
	// Fields
    private int[][] currentPosition;
    private int length;

    // Constructor
    protected MovableParts() {
        this.currentPosition = new int[1][2];
        this.length = 1;
    }

    // Methods
    public int[][] getCurrentPosition() {
        return this.currentPosition;
    }

    public void setCurrentPosition(int i, int x, int y) {
        this.currentPosition[i][0] = x;
        this.currentPosition[i][1] = y;
    }

    public void setCurrentPosition(int i, int[][] a) {
        this.currentPosition[i] = a[0];;
    }

    public int getLength() {
        return this.length;
    }

    public void setLength(int l) {
        this.length = l;
    }
    
    public void addLength() {
    	this.length += 1;
    }
    
    public void longerCurrentPosition() {
    	this.currentPosition = new int [this.length][2];
    }

    // Abstract methods
    public abstract int[][] getNewPos();

}
